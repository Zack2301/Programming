
package shop;



import java.io.IOException;

public class Main
{
  public static void main(String[] args)
    throws IOException
  {
   OnlineShop shop = new OnlineShop();
  }
}


